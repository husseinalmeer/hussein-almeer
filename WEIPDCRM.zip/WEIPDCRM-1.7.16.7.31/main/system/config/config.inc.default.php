<?php
if (!defined("DCRM")) {
	exit;
}
define("DCRM_LANG", "Detect");
define("DCRM_MAXLOGINFAIL", 5);
define("DCRM_SHOWLIST", 1);
define("DCRM_SHOW_NUM", 5);
define("DCRM_ALLOW_FULLLIST", 2);
define("DCRM_SPEED_LIMIT", 0);
define("DCRM_DIRECT_DOWN", 1);
define("DCRM_PCINDEX", 1);
define("DCRM_MOBILE", 2);
define("DCRM_SCREENSHOTS", 2);
define("DCRM_REPORTING", 1);
define("DCRM_REPORT_LIMIT", 1);
define("DCRM_UPDATELOGS", 1);
define("DCRM_DESCRIPTION", 2);
define("DCRM_MOREINFO", 2);
define("DCRM_MULTIINFO", 2);
define("DCRM_LISTS_METHOD", 3);
define("DCRM_CHECK_METHOD", 1);
define("DCRM_REPOURL", "");
define("DCRM_LOGINFAILRESETTIME", 600);
?>